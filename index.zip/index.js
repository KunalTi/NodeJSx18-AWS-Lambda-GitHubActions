exports.handler = async (event) => {
  const now = new Date();
  const response = {
    statusCode: 200,
    body: `The current date and time is ${now.toISOString()}.`
  };
  return response;
};

